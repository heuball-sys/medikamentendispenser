#pragma once
// Hilfs-Header fuer den Matrix-Scan des Medikamentendispensers
#include <driver/gpio.h>
#include <esp_rom_sys.h>
