# Smarter Medikamentendispenser – 7 Tage × 4 Tageszeiten mit ESP32 & Home Assistant

Ein Wochen-Dispenser mit **28 herausnehmbaren Töpfchen** (Mo–So × Morgens, Mittags, Abends, Nachts). Unter jedem Töpfchen sitzt ein Cherry-MX-kompatibler Tastaturschalter. Ein ESP32 erkennt, welche Fächer entnommen wurden, und meldet das per WLAN an **Home Assistant**. Wird die Mittagsdosis nicht rechtzeitig entnommen, kommt eine Push-Nachricht aufs Handy.

## Highlights
- 28 Fächer, alle gleichzeitig erkannt (Diodenmatrix, kein eigenes PCB)
- Firmware mit **ESPHome**: eine YAML-Datei, kein Programmieren nötig
- Zweifarbige, bündig eingelassene Beschriftung
- Weitgehend ohne Stützmaterial druckbar (Düse 0,4 mm)
- Alle Maße als Parameter in Fusion anpassbar
- Fertiges Home-Assistant-Paket für stündliche Erinnerungen

## Was du brauchst
- 1× ESP32-Board, 38 Pins, USB-C, CP2102 (Pinreihenabstand 25,4 mm)
- 28× Cherry-MX-kompatible Switches (3-Pin)
- 28× Dioden 1N4148
- 4× Einpressmuttern M3 × 5 × 4 mm + 4× M3-Senkkopfschrauben
- Isolierter Draht, Lötkolben, Multimeter

Vollständige Teileliste mit Links, Montage, Verdrahtung, Flashen und Fehlersuche: siehe **Bauanleitung (PDF)** in den Dateien.

## Dateien
- Druckdateien: Grundkörper mit Schrift-Inlay (3MF, zweifarbig), Bodenplatte, Töpfchen
- `medikamentendispenser.yaml` + `dispenser_pins.h` – ESPHome-Firmware
- `secrets.yaml.example` – Vorlage für WLAN und Schlüssel
- `medikamente_package.yaml` – Home-Assistant-Erinnerungen

## Druckhinweise
PLA oder PETG, 0,2 mm Schichthöhe, 3 Wände, 15–20 % Füllung, kein Support. Grundkörper mit der Oberseite aufs Druckbett. Erst **ein** Töpfchen testen, dann die restlichen 27 drucken.

## Hinweis
Dies ist ein Bastelprojekt und eine Erinnerungshilfe, **kein Medizinprodukt**. Der Dispenser erkennt nur, ob ein Töpfchen entnommen wurde, nicht ob das Medikament eingenommen wurde. Verlass dich bei wichtigen Medikamenten nicht allein darauf.
